#ifndef MC_HARDWARE_H_INCLUDED
#define MC_HARDWARE_H_INCLUDED

#include <Arduino.h>;

#endif // MC_HARDWARE_H_INCLUDED
