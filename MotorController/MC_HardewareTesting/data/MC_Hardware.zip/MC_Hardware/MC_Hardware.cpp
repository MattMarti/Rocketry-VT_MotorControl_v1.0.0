#include "MC_Hardware.h"

using namespace MC_Pins;
uint8_t[3] checkCont()
{
    uint8_t MC_Cont[3] = {0, 0, 0};
    int ventCont = analogRead(VENT_CONT_PIN);
    Serial.println(ventCont, DEC);
    if (ventCont > 1)
    {
        MC_Cont[0] = 1;

    }


}
