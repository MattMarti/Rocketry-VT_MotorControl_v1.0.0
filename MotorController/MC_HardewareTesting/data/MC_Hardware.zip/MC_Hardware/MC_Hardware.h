#ifndef MC_HARDWARE_H_INCLUDED
#define MC_HARDWARE_H_INCLUDED

#include <Arduino.h>
#include <motor_controller_config.h>

uint8_t[3] checkCont();


#endif // MC_HARDWARE_H_INCLUDED
